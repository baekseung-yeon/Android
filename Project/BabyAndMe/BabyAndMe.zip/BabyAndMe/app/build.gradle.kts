plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.babyandme"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.babyandme"
        minSdk = 32
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
        isCoreLibraryDesugaringEnabled = true // ✅ desugaring 활성화
    }
}

dependencies {
    // ✅ 핵심 AndroidX + Material (CalendarView는 기본 SDK 포함이므로 별도 라이브러리 없음)
    implementation("androidx.lifecycle:lifecycle-process:2.6.2")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.core:core:1.9.0")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // ✅ Gson (일정 저장 시 사용된다면 유지)
    implementation("com.google.code.gson:gson:2.10.1")

    // ✅ Java 8+ API 사용 가능하게 (LocalDate 등)
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // ✅ 테스트
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}