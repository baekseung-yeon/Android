package com.example.babyandme;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.DayViewHolder> {

    private final ArrayList<Calendar> dateList;
    private final OnDateSelectedListener listener;
    private final Calendar today = Calendar.getInstance();
    private final int targetMonth;

    public interface OnDateSelectedListener {
        void onDateSelected(Calendar date);
    }

    public CalendarAdapter(Calendar calendar, OnDateSelectedListener listener) {
        this.listener = listener;
        this.targetMonth = calendar.get(Calendar.MONTH); // 현재 월
        this.dateList = generateDates(calendar);
    }

    private ArrayList<Calendar> generateDates(Calendar baseCalendar) {
        ArrayList<Calendar> list = new ArrayList<>();

        Calendar firstOfMonth = (Calendar) baseCalendar.clone();
        firstOfMonth.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = firstOfMonth.get(Calendar.DAY_OF_WEEK) - 1; // 일:0 ~ 토:6

        // 앞쪽 공백
        for (int i = 0; i < firstDayOfWeek; i++) {
            list.add(null); // 빈칸 처리
        }

        // 현재 월 날짜만 추가
        int maxDay = firstOfMonth.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDay; i++) {
            Calendar day = (Calendar) firstOfMonth.clone();
            day.set(Calendar.DAY_OF_MONTH, i);
            list.add(day);
        }

        return list;
    }

    @Override
    public DayViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_calendar_day, parent, false);
        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DayViewHolder holder, int position) {
        Calendar date = dateList.get(position);

        if (date == null) {
            holder.dayText.setText("");
            holder.dayText.setBackgroundColor(Color.TRANSPARENT);
            holder.itemView.setClickable(false);
            return;
        }

        int day = date.get(Calendar.DAY_OF_MONTH);
        holder.dayText.setText(String.valueOf(day));

        // 오늘 날짜 강조
        if (isSameDay(date, today)) {
            holder.dayText.setBackgroundResource(R.drawable.bg_today_circle); // 흰 원
        } else {
            holder.dayText.setBackgroundColor(Color.TRANSPARENT);
        }

        holder.itemView.setOnClickListener(v -> listener.onDateSelected(date));
    }

    @Override
    public int getItemCount() {
        return dateList.size();
    }

    public static class DayViewHolder extends RecyclerView.ViewHolder {
        TextView dayText;

        public DayViewHolder(View itemView) {
            super(itemView);
            dayText = itemView.findViewById(R.id.dayText);
        }
    }

    private boolean isSameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
                && a.get(Calendar.MONTH) == b.get(Calendar.MONTH)
                && a.get(Calendar.DAY_OF_MONTH) == b.get(Calendar.DAY_OF_MONTH);
    }
}
