package com.example.babyandme;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class CalendarActivity extends AppCompatActivity {

    private TextView monthText, monthEnglishText, selectedDateText;
    private LinearLayout eventList;
    private RecyclerView calendarRecyclerView;
    private Calendar currentCalendar;
    private Calendar selectedCalendar;

    private static final int REQUEST_ADD_EVENT = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        monthText = findViewById(R.id.monthText);
        monthEnglishText = findViewById(R.id.monthEnglishText);
        selectedDateText = findViewById(R.id.selectedDateText);
        eventList = findViewById(R.id.eventList);
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView);

        currentCalendar = Calendar.getInstance();
        selectedCalendar = (Calendar) currentCalendar.clone();

        updateMonthHeader();

        calendarRecyclerView.setLayoutManager(new GridLayoutManager(this, 7));
        CalendarAdapter adapter = new CalendarAdapter(currentCalendar, this::onDateSelected);
        calendarRecyclerView.setAdapter(adapter);

        ImageButton addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(CalendarActivity.this, AddAnniversaryStep1Activity.class);
            startActivityForResult(intent, REQUEST_ADD_EVENT);
        });

        onDateSelected(selectedCalendar);

        NavigationHelper.setupNavigation(this, "calendar");
    }

    private void updateMonthHeader() {
        int month = currentCalendar.get(Calendar.MONTH) + 1;
        monthText.setText(String.valueOf(month));
        SimpleDateFormat engFormat = new SimpleDateFormat("MMMM", Locale.ENGLISH);
        monthEnglishText.setText(engFormat.format(currentCalendar.getTime()));
    }

    private void onDateSelected(Calendar selectedDate) {
        selectedCalendar = (Calendar) selectedDate.clone();

        SimpleDateFormat dateFormat = new SimpleDateFormat("M월 d일 E요일", Locale.KOREAN);
        selectedDateText.setText(dateFormat.format(selectedDate.getTime()));

        eventList.removeAllViews();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA);
        String selectedDateStr = sdf.format(selectedDate.getTime());

        for (String e : EventStorage.eventList) {
            if (e.startsWith(selectedDateStr)) {
                addEvent(e.split(": ", 2)[1]);
            }
        }
    }

    private void addEvent(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#6F6333"));
        tv.setTextSize(22);
        tv.setTypeface(getResources().getFont(R.font.baby));
        eventList.addView(tv);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ADD_EVENT && resultCode == RESULT_OK && data != null) {
            String content = data.getStringExtra("content");
            String date = data.getStringExtra("date");

            if (content != null && date != null) {
                String full = date + ": " + content;
                EventStorage.eventList.add(full);

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA);
                String selectedDateStr = sdf.format(selectedCalendar.getTime());

                if (selectedDateStr.equals(date)) {
                    addEvent(content);
                }
            }
        }
    }
}
