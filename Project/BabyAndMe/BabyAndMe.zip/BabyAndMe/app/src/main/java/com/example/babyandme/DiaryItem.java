package com.example.babyandme;

public class DiaryItem {
    private String title;

    private String date;
    private String content;


    public DiaryItem(String title, String content, String date) {
        this.title = title;
        this.date = date;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public String getDate() {
        return date;
    }


}
