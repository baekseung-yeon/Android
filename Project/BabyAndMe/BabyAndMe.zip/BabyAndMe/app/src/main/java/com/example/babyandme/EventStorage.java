package com.example.babyandme;

import java.util.ArrayList;

public class EventStorage {
    public static final ArrayList<String> eventList = new ArrayList<>();

    public static void clear() {
        eventList.clear();
    }
}
