package com.example.babyandme;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.style.RelativeSizeSpan;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;

import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

public class HomeActivity extends AppCompatActivity {

    private TextView babyNameText, ddayText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        babyNameText = findViewById(R.id.babyNameText);
        ddayText = findViewById(R.id.ddayText);

        // SharedPreferences에서 값 불러오기
        TextView babyNameText = findViewById(R.id.babyNameText);
        SharedPreferences prefs = getSharedPreferences("BabyPrefs", MODE_PRIVATE);
        String babyName = prefs.getString("babyName", "아기");
        String gender = prefs.getString("gender", "male");
        String birthDateStr = prefs.getString("birthDate", "2020.01.01");


        // 이름 설정
        String text = "나는 " + babyName + " (이)에요.";
        SpannableString spannable = new SpannableString(text);

        int nameStart = text.indexOf(babyName);
        int nameEnd = nameStart + babyName.length();
        int color = gender.equals("male") ? Color.parseColor("#70BCE4") : Color.parseColor("#FECBDB");

        spannable.setSpan(new ForegroundColorSpan(color), nameStart, nameEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        babyNameText.setText(spannable);


        // D-Day 계산
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
            Date birthDate = sdf.parse(birthDateStr);
            long diffInMillis = new Date().getTime() - birthDate.getTime();
            int days = (int) (diffInMillis / (1000 * 60 * 60 * 24)) + 1;

            String ddayDisplay = "함께한 지 " + days + "일";
            SpannableString spannableDday = new SpannableString(ddayDisplay);

            int start = ddayDisplay.indexOf(String.valueOf(days));
            int end = start + String.valueOf(days).length();

            spannableDday.setSpan(
                    new RelativeSizeSpan(1.15f), // 텍스트 크기 1.5배
                    start,
                    end,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            );

            ddayText.setText(spannableDday);

            // 캐릭터 이미지 조건 변경
            ImageView babyCharacter = findViewById(R.id.babyCharacter);
            if (days >= 500) {
                babyCharacter.setImageResource(R.drawable.character_2);  // 500일 이상일 때 캐릭터 변경
            }

        } catch (Exception e) {
            ddayText.setText("함께한 지 0일");
        }

        ImageView babyCharacter = findViewById(R.id.babyCharacter);

        // 좌우로 움직이는 애니메이션
        ObjectAnimator wobble = ObjectAnimator.ofFloat(babyCharacter, "rotation", -8f, 8f);
        wobble.setDuration(1200); // 한쪽으로 기울이는 데 걸리는 시간
        wobble.setRepeatMode(ObjectAnimator.REVERSE);
        wobble.setRepeatCount(ObjectAnimator.INFINITE);
        wobble.setInterpolator(new LinearInterpolator());
        wobble.start();
        babyCharacter.post(() -> {
            babyCharacter.setPivotX(babyCharacter.getWidth() / 2f);
            babyCharacter.setPivotY(babyCharacter.getHeight());
        });

        NavigationHelper.setupNavigation(this, "home");
    }
}
