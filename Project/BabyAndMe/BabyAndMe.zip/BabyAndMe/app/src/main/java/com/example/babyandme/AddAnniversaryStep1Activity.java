package com.example.babyandme;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AddAnniversaryStep1Activity extends AppCompatActivity {

    private static final int REQUEST_STEP2 = 200;
    private EditText inputContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_anniversary_step1);

        inputContent = findViewById(R.id.inputContent);
        ImageView closeBtn = findViewById(R.id.closeBtn);
        Button nextBtn = findViewById(R.id.nextBtn);

        closeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, CalendarActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        nextBtn.setOnClickListener(v -> {
            String content = inputContent.getText().toString().trim();
            if (content.isEmpty()) {
                Toast.makeText(this, "내용을 입력해주세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(this, AddAnniversaryStep2Activity.class);
            intent.putExtra("content", content);
            startActivityForResult(intent, REQUEST_STEP2);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_STEP2 && resultCode == RESULT_OK && data != null) {
            setResult(RESULT_OK, data);
            finish(); // CalendarActivity로 돌아감
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
