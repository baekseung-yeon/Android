package com.example.babyandme;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

public class MyApp extends Application implements DefaultLifecycleObserver {

    @Override
    public void onCreate() {
        super.onCreate();

        // 앱 생명주기 감시 시작
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

    // ✅ 앱이 포그라운드로 올라왔을 때 호출
    @Override
    public void onStart(LifecycleOwner owner) {
        SharedPreferences prefs = getSharedPreferences("diary", MODE_PRIVATE);
        boolean firstLaunch = prefs.getBoolean("first_launch", true);

        if (firstLaunch) {
            // ✅ 앱이 완전히 종료됐다가 다시 켜졌다고 판단 → 다이어리 초기화
            prefs.edit()
                    .remove("diary_list")              // 다이어리 목록 삭제
                    .putBoolean("first_launch", false) // 다시는 초기화하지 않도록 설정
                    .apply();
        }
    }

    // ✅ 앱이 백그라운드로 내려갈 때 호출
    @Override
    public void onStop(LifecycleOwner owner) {
        SharedPreferences prefs = getSharedPreferences("diary", MODE_PRIVATE);
        prefs.edit()
                .putBoolean("first_launch", true) // 다음 실행 시 초기화하게끔 설정
                .apply();
    }
}