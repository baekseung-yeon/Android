package com.example.babyandme;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DiaryViewActivity extends AppCompatActivity {

    private TextView dateText, dayText;
    private EditText titleInput, contentInput;
    private ImageView closeBtn, menuBtn;

    private String fullDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_view);

        dateText = findViewById(R.id.dateText);
        dayText = findViewById(R.id.dayText);
        titleInput = findViewById(R.id.titleInput);
        contentInput = findViewById(R.id.contentInput);
        closeBtn = findViewById(R.id.close);
        menuBtn = findViewById(R.id.menu);

        titleInput.setEnabled(false);
        contentInput.setEnabled(false);

        ImageView photoBtn = findViewById(R.id.photoButton);
        if (photoBtn != null) photoBtn.setVisibility(View.GONE);

        Intent intent = getIntent();
        String title = "", content = "", dateRaw = "";
        if (intent != null) {
            title = intent.getStringExtra("title");
            content = intent.getStringExtra("content");
            dateRaw = intent.getStringExtra("date");

            fullDate = dateRaw;

            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN);
                SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy년 M월 d일", Locale.KOREAN);
                SimpleDateFormat outputDayFormat = new SimpleDateFormat("E요일", Locale.KOREAN);

                Date parsedDate = inputFormat.parse(dateRaw);
                if (parsedDate != null) {
                    dateText.setText(outputDateFormat.format(parsedDate));
                    dayText.setText(outputDayFormat.format(parsedDate));
                } else {
                    dateText.setText(dateRaw);
                    dayText.setText("");
                }
            } catch (Exception e) {
                dateText.setText(dateRaw);
                dayText.setText("");
            }

            titleInput.setText(title);
            contentInput.setText(content);
        }

        String finalTitle = title;
        String finalContent = content;
        String finalDate = dateRaw;

        closeBtn.setOnClickListener(v -> finish());

        menuBtn.setOnClickListener(v -> {
            View popupView = getLayoutInflater().inflate(R.layout.popup_menu_custom, null);
            popupView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            int popupWidth = popupView.getMeasuredWidth();

            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int[] location = new int[2];
            menuBtn.getLocationOnScreen(location);
            int menuX = location[0];

            int offsetX = screenWidth - (menuX + popupWidth + 40); // 오른쪽 여백

            PopupWindow popupWindow = new PopupWindow(
                    popupView,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    true
            );

            popupWindow.setBackgroundDrawable(getDrawable(android.R.color.transparent));
            popupWindow.setElevation(20f);
            popupWindow.showAsDropDown(menuBtn, offsetX, 10);

            // 수정 버튼
            popupView.findViewById(R.id.btnEdit).setOnClickListener(view -> {
                popupWindow.dismiss();
                Intent editIntent = new Intent(this, DiaryWriteActivity.class);
                editIntent.putExtra("title", finalTitle);
                editIntent.putExtra("content", finalContent);
                editIntent.putExtra("date", finalDate);
                editIntent.putExtra("isEdit", true); // 수정모드
                startActivity(editIntent);
            });

            // 삭제 버튼
            popupView.findViewById(R.id.btnDelete).setOnClickListener(view -> {
                popupWindow.dismiss();

                SharedPreferences prefs = getSharedPreferences("diary", MODE_PRIVATE);
                String json = prefs.getString("diary_list", null);
                Gson gson = new Gson();
                Type type = new TypeToken<ArrayList<DiaryItem>>() {}.getType();
                ArrayList<DiaryItem> diaryList = gson.fromJson(json, type);

                if (diaryList != null) {
                    for (int i = 0; i < diaryList.size(); i++) {
                        DiaryItem item = diaryList.get(i);
                        if (item.getTitle().equals(finalTitle) &&
                                item.getContent().equals(finalContent) &&
                                item.getDate().equals(finalDate)) {
                            diaryList.remove(i);
                            break;
                        }
                    }

                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("diary_list", gson.toJson(diaryList));
                    editor.apply();

                    Toast.makeText(this, "일기가 삭제되었습니다", Toast.LENGTH_SHORT).show();
                }

                // 리스트 화면으로 이동
                Intent listIntent = new Intent(this, DiaryListActivity.class);
                startActivity(listIntent);
                finish();
            });
        });
    }
}
