package com.example.babyandme;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DiaryWriteActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_GALLERY = 101;

    private EditText titleInput, contentInput;
    private TextView dateText, dayText;
    private ImageView photoButton;

    // ✅ 수정 모드 여부 판단 변수
    private boolean isEdit = false;
    private String editDate = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_write);

        titleInput = findViewById(R.id.titleInput);
        contentInput = findViewById(R.id.contentInput);
        dateText = findViewById(R.id.dateText);
        dayText = findViewById(R.id.dayText);
        ImageView closeBtn = findViewById(R.id.close);
        ImageView saveBtn = findViewById(R.id.save);
        photoButton = findViewById(R.id.photoButton);

        // 오늘 날짜 기본값
        String fullDate = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN).format(new Date());
        String displayDate = new SimpleDateFormat("yyyy년 M월 d일", Locale.KOREAN).format(new Date());
        String dayOfWeek = new SimpleDateFormat("E요일", Locale.KOREAN).format(new Date());

        dateText.setText(displayDate);
        dayText.setText(dayOfWeek);

        // ✅ 수정 모드 처리
        Intent intent = getIntent();
        if (intent != null) {
            isEdit = intent.getBooleanExtra("isEdit", false);

            if (isEdit) {
                editDate = intent.getStringExtra("date");
                String editTitle = intent.getStringExtra("title");
                String editContent = intent.getStringExtra("content");

                titleInput.setText(editTitle);
                contentInput.setText(editContent);

                try {
                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN);
                    SimpleDateFormat displayFormat = new SimpleDateFormat("yyyy년 M월 d일", Locale.KOREAN);
                    SimpleDateFormat dayFormat = new SimpleDateFormat("E요일", Locale.KOREAN);

                    Date parsed = inputFormat.parse(editDate);
                    if (parsed != null) {
                        dateText.setText(displayFormat.format(parsed));
                        dayText.setText(dayFormat.format(parsed));
                    }
                } catch (Exception e) {
                    // 실패 시 현재 날짜 유지
                }
            }
        }

        // 닫기 버튼
        closeBtn.setOnClickListener(v -> finish());

        // 저장 버튼
        saveBtn.setOnClickListener(v -> {
            String title = titleInput.getText().toString().trim();
            String content = contentInput.getText().toString().trim();

            if (title.isEmpty()) {
                Toast.makeText(this, "제목을 입력해주세요", Toast.LENGTH_SHORT).show();
                return;
            }

            // 기존 목록 가져오기
            SharedPreferences prefs = getSharedPreferences("diary", MODE_PRIVATE);
            Gson gson = new Gson();
            String json = prefs.getString("diary_list", null);
            Type type = new TypeToken<ArrayList<DiaryItem>>(){}.getType();
            ArrayList<DiaryItem> diaryList = gson.fromJson(json, type);

            if (diaryList == null) diaryList = new ArrayList<>();

            // ✅ 수정일 경우, 해당 날짜의 기존 항목 삭제
            if (isEdit && editDate != null) {
                for (int i = 0; i < diaryList.size(); i++) {
                    if (diaryList.get(i).getDate().equals(editDate)) {
                        diaryList.remove(i);
                        break;
                    }
                }
            }

            // 저장용 날짜
            String saveDate = isEdit ? editDate : new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN).format(new Date());

            // 새 항목 추가
            DiaryItem newItem = new DiaryItem(title, content, saveDate);
            diaryList.add(newItem);

            // 저장
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("diary_list", gson.toJson(diaryList));
            editor.apply();

            // 이동
            Intent listIntent = new Intent(this, DiaryListActivity.class);
            startActivity(listIntent);
            finish();
        });

        // 갤러리 선택
        photoButton.setOnClickListener(v -> {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, REQUEST_CODE_GALLERY);
        });
    }

    // 이미지 선택 처리
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            if (selectedImage != null) {
                photoButton.setImageURI(selectedImage);
                Toast.makeText(this, "이미지가 선택되었습니다", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
