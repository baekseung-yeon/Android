package com.example.babyandme;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class DiaryListActivity extends AppCompatActivity {

    private LinearLayout diaryList;

    // ✅ 앱이 완전히 죽었다가 켜졌는지 확인하는 static 변수
    private static boolean wasAppKilled = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_list);

        diaryList = findViewById(R.id.diaryList);
        ImageButton writeButton = findViewById(R.id.writeButton);

        // ✅ 앱이 완전히 종료된 후 처음 실행된 경우 → 초기화 실행
        if (wasAppKilled) {
            getSharedPreferences("diary", MODE_PRIVATE)
                    .edit()
                    .remove("diary_list")
                    .apply();
            wasAppKilled = false; // 초기화는 첫 실행에만
        }

        // ✅ 저장된 다이어리 데이터 불러오기
        SharedPreferences prefs = getSharedPreferences("diary", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString("diary_list", null);
        Type type = new TypeToken<ArrayList<DiaryItem>>(){}.getType();
        ArrayList<DiaryItem> diaryListData = gson.fromJson(json, type);

        if (diaryListData != null) {
            for (DiaryItem item : diaryListData) {
                addDiaryItem(item.getTitle(), item.getDate(), item.getContent());
            }
        }

        writeButton.setOnClickListener(view -> {
            Intent intent = new Intent(DiaryListActivity.this, DiaryWriteActivity.class);
            startActivity(intent);
        });

        NavigationHelper.setupNavigation(this, "diary");
    }

    private void addDiaryItem(String title, String date, String content) {
        LinearLayout itemLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(0, 0, 0, 30);
        itemLayout.setLayoutParams(layoutParams);
        itemLayout.setOrientation(LinearLayout.HORIZONTAL);
        itemLayout.setBackgroundResource(R.drawable.rounded_button_white);
        itemLayout.setPadding(50, 50, 50, 50);
        itemLayout.setElevation(0);
        itemLayout.setStateListAnimator(null);

        TextView titleView = new TextView(this);
        titleView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        titleView.setText(title);
        titleView.setTextSize(22);
        titleView.setTextColor(Color.parseColor("#6F6333"));
        titleView.setTypeface(getResources().getFont(R.font.baby));

        TextView dateView = new TextView(this);
        dateView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        dateView.setText(date);
        dateView.setTextSize(18);
        dateView.setTextColor(Color.parseColor("#6F6333"));
        dateView.setTypeface(getResources().getFont(R.font.baby));

        itemLayout.addView(titleView);
        itemLayout.addView(dateView);
        diaryList.addView(itemLayout);

        // ✅ 클릭 시 상세 보기 화면으로 이동
        itemLayout.setOnClickListener(v -> {
            Intent intent = new Intent(DiaryListActivity.this, DiaryViewActivity.class);
            intent.putExtra("title", title);
            intent.putExtra("date", date);
            intent.putExtra("content", content);
            startActivity(intent);
        });
    }
}
