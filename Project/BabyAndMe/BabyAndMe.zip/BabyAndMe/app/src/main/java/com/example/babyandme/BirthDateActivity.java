package com.example.babyandme;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class BirthDateActivity extends AppCompatActivity {

    private NumberPicker yearPicker, monthPicker, dayPicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_birth_date);

        yearPicker = findViewById(R.id.yearPicker);
        monthPicker = findViewById(R.id.monthPicker);
        dayPicker = findViewById(R.id.dayPicker);
        TextView selectedDateText = findViewById(R.id.selectedDateText);
        Button prevBtn = findViewById(R.id.prevButton);
        Button nextBtn = findViewById(R.id.nextButton);

        // Picker 기본값 설정
        yearPicker.setMinValue(2000);
        yearPicker.setMaxValue(2030);
        yearPicker.setValue(2020);

        monthPicker.setMinValue(1);
        monthPicker.setMaxValue(12);
        monthPicker.setValue(1);

        dayPicker.setMinValue(1);
        dayPicker.setMaxValue(31);
        dayPicker.setValue(1);

        // 날짜 텍스트 실시간 반영
        Runnable updateDateText = () -> {
            int year = yearPicker.getValue();
            int month = monthPicker.getValue();
            int day = dayPicker.getValue();
            String birthDate = String.format("%04d. %02d. %02d", year, month, day);
            selectedDateText.setText(birthDate);
        };

        NumberPicker.OnValueChangeListener listener = (picker, oldVal, newVal) -> updateDateText.run();

        yearPicker.setOnValueChangedListener(listener);
        monthPicker.setOnValueChangedListener(listener);
        dayPicker.setOnValueChangedListener(listener);

        // 일수 자동 조정
        monthPicker.setOnValueChangedListener((picker, oldVal, newVal) -> {
            updateDayPicker(yearPicker.getValue(), newVal);
            updateDateText.run();
        });
        yearPicker.setOnValueChangedListener((picker, oldVal, newVal) -> {
            updateDayPicker(newVal, monthPicker.getValue());
            updateDateText.run();
        });

        // 초기 텍스트 표시
        updateDateText.run();

        // 이전 버튼 (성별 선택 화면으로 이동)
        prevBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, GenderSelectActivity.class);
            startActivity(intent);
            finish();
        });

        // 다음 버튼 (생년월일 저장 + 메인으로 이동)
        nextBtn.setOnClickListener(v -> {
            int year = yearPicker.getValue();
            int month = monthPicker.getValue();
            int day = dayPicker.getValue();

            String birthDate = String.format("%04d.%02d.%02d", year, month, day);

            // ✅ SharedPreferences에 저장
            SharedPreferences prefs = getSharedPreferences("BabyPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("birthDate", birthDate);
            editor.apply();

            // Toast로 확인
            Toast.makeText(this, "선택한 날짜: " + birthDate, Toast.LENGTH_SHORT).show();

            // 다음 화면으로 이동
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
            finish();
        });
    }

    // 월별 최대 일 수 자동 반영
    private void updateDayPicker(int year, int month) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, 1);
        int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int currentDay = dayPicker.getValue();

        dayPicker.setMaxValue(maxDay);
        if (currentDay > maxDay) {
            dayPicker.setValue(maxDay);
        }
    }
}
