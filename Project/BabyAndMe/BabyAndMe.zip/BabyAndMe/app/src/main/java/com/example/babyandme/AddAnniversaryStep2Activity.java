package com.example.babyandme;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddAnniversaryStep2Activity extends AppCompatActivity {

    private CalendarView calendarView;
    private long selectedDateMillis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_anniversary_step2);

        calendarView = findViewById(R.id.calendarView);
        ImageView closeBtn = findViewById(R.id.closeBtn);
        Button backBtn = findViewById(R.id.backBtn);
        Button doneBtn = findViewById(R.id.doneBtn);

        selectedDateMillis = calendarView.getDate();

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDateMillis = new Date(year - 1900, month, dayOfMonth).getTime();
        });

        closeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, CalendarActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        backBtn.setOnClickListener(v -> finish());

        doneBtn.setOnClickListener(v -> {
            String content = getIntent().getStringExtra("content");
            String formattedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
                    .format(new Date(selectedDateMillis));

            Intent resultIntent = new Intent();
            resultIntent.putExtra("content", content);
            resultIntent.putExtra("date", formattedDate);
            setResult(RESULT_OK, resultIntent);
            finish(); // Step1Activity로 돌아감 → CalendarActivity로 전달됨
        });
    }
}
