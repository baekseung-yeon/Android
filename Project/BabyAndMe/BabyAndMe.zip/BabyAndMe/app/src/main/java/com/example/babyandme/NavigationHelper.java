package com.example.babyandme;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;

public class NavigationHelper {

    public static void setupNavigation(Activity activity, String currentPage) {
        ImageView navHome = activity.findViewById(R.id.nav_home);
        ImageView navDiary = activity.findViewById(R.id.nav_diary);
        ImageView navCalendar = activity.findViewById(R.id.nav_calendar);
        ImageView navSetting = activity.findViewById(R.id.nav_setting);

        Context context = activity.getApplicationContext();

        // 아이콘 초기화
        navHome.setImageResource(currentPage.equals("home") ? R.drawable.nav_home_selected : R.drawable.nav_home);
        navDiary.setImageResource(currentPage.equals("diary") ? R.drawable.nav_diary_selected : R.drawable.nav_diary);
        navCalendar.setImageResource(currentPage.equals("calendar") ? R.drawable.nav_calendar_selected : R.drawable.nav_calendar);
        navSetting.setImageResource(currentPage.equals("setting") ? R.drawable.nav_setting_selected : R.drawable.nav_setting);

        // 홈 이동
        navHome.setOnClickListener(v -> {
            if (!currentPage.equals("home")) {
                Intent intent = new Intent(activity, HomeActivity.class);
                activity.startActivity(intent);
                activity.finish();
            }
        });

        // 일기 이동
        navDiary.setOnClickListener(v -> {
            if (!currentPage.equals("diary")) {
                Intent intent = new Intent(activity, DiaryListActivity.class);
                activity.startActivity(intent);
                activity.finish();
            }
        });

        // 캘린더 이동
        navCalendar.setOnClickListener(v -> {
            if (!currentPage.equals("calendar")) {
                Intent intent = new Intent(activity, CalendarActivity.class);
                activity.startActivity(intent);
                activity.finish();
            }
        });

        // 설정 이동 (예정)
        navSetting.setOnClickListener(v -> {
            // 구현 예정 시 연결
        });
    }
}
