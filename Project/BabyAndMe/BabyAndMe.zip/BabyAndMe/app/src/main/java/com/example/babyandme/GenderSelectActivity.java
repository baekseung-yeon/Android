package com.example.babyandme;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GenderSelectActivity extends AppCompatActivity {

    private LinearLayout maleBox, femaleBox;
    private String selectedGender = ""; // "male" 또는 "female"

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gender_select);

        maleBox = findViewById(R.id.maleBox);
        femaleBox = findViewById(R.id.femaleBox);
        Button prevBtn = findViewById(R.id.prevButton);
        Button nextBtn = findViewById(R.id.nextButton);

        // 남아 클릭
        maleBox.setOnClickListener(v -> {
            selectedGender = "male";
            maleBox.setBackgroundResource(R.drawable.gender_selected);    // 흰색 테두리
            femaleBox.setBackgroundResource(R.drawable.gender_unselected); // 여아 선택 해제
        });

        // 여아 클릭
        femaleBox.setOnClickListener(v -> {
            selectedGender = "female";
            femaleBox.setBackgroundResource(R.drawable.gender_selected);
            maleBox.setBackgroundResource(R.drawable.gender_unselected);
        });

        // 이전 버튼
        prevBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, BabyNameActivity.class);
            startActivity(intent);
            finish();
        });
        // 다음 버튼
        nextBtn.setOnClickListener(v -> {
            if (selectedGender.isEmpty()) {
                Toast.makeText(this, "성별을 선택해주세요.", Toast.LENGTH_SHORT).show();
            } else {
                // ✅ SharedPreferences에 저장
                getSharedPreferences("BabyPrefs", MODE_PRIVATE)
                        .edit()
                        .putString("gender", selectedGender)
                        .apply();

                // 다음 화면으로 이동
                Intent intent = new Intent(this, BirthDateActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
