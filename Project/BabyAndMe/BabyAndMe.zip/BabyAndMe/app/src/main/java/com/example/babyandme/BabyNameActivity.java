package com.example.babyandme;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BabyNameActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baby_name);

        EditText nameInput = findViewById(R.id.babyNameInput);
        Button nextBtn = findViewById(R.id.nextButton);

        nameInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                nameInput.setTextColor(Color.parseColor("#6F6333"));
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        nextBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(this, "아기 이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
            } else {
                // ✅ 이름 저장
                SharedPreferences prefs = getSharedPreferences("BabyPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("babyName", name); // "babyName" 키로 저장
                editor.apply();

                // 다음 화면으로 이동
                Intent intent = new Intent(this, GenderSelectActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
